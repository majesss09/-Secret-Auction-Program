from art import logo
print(logo)
print("Welcome to the secret auction program.")
bidders = {}
more_bidders = "yes"
while more_bidders == "yes":
    name = input("What is your name?: ")
    bid = float(input("What's your bid?: $"))
    bidders[name] = bid
    more_bidders = input("Are there any other bidders? Type 'yes' or 'no'.\n")
    print("\n"*20)

winner = ["name",0]
for key in bidders:
    if bidders[key] >= winner[1]:
        winner[0] = key
        winner[1] = bidders[key]

print(f"The winner is {winner[0]}, with a bid of ${winner[1]}.")